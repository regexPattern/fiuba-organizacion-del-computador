# El Asalto

- [Video del juego real](https://www.youtube.com/watch?v=8QOmm8-jh8k)

| Nombre | Padrón | 
| --- | --- |
| Rodrigo Vargas | 97076 |
| Gerónimo Fanti | 109712 |
| Melina Loscalzo | 106571 |
| Carlos Castillo | 108535 |
